     <!-- footer -->
     <footer class="footer"> © 2021 All rights reserved. </footer>
            <!-- End footer -->
        </div>
        <!-- End Page wrapper  -->
    </div>
    <!-- End Wrapper -->
</body>
</html>
